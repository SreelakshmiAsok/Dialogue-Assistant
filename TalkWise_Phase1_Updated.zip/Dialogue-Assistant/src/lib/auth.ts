export const setToken = (token: string, role: string) => {
  if (typeof window !== "undefined") {
    localStorage.setItem("access_token", token);
    localStorage.setItem("user_role", role);
    if (role === "parent") {
      localStorage.setItem("parent_access_token", token);
    }
  }
};

export const setParentToken = (token: string) => {
  if (typeof window !== "undefined") {
    localStorage.setItem("parent_access_token", token);
  }
};

export const getParentToken = () => {
  if (typeof window !== "undefined") {
    return localStorage.getItem("parent_access_token");
  }
  return null;
};

export const getToken = () => {
  if (typeof window !== "undefined") {
    return localStorage.getItem("access_token");
  }
  return null;
};

export const getRole = () => {
  if (typeof window !== "undefined") {
    return localStorage.getItem("user_role");
  }
  return null;
};

export const clearAuth = () => {
  if (typeof window !== "undefined") {
    localStorage.removeItem("access_token");
    localStorage.removeItem("user_role");
    localStorage.removeItem("parent_access_token");
  }
};

export const getAuthHeaders = (): Record<string, string> => {
  const token = getToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
};
